# POST-PLAN sensitivity variant `threew_noann` (parent: data/processed/threew)

Built by src/sens/threewseu/build.py (alternative cloud view; secondary sensitivity analysis). Not confirmatory: it cannot change any pre-specified verdict. Windows, labels, meta (all columns, row order, window_id) and channels are copied unchanged from the parent; raw_*.npy are not included (pairs A and B do not use them). Features are recomputed with escalation.features.window_features from the parent's stored raw windows (one call per view, channels in the stored order, edge channels first) unless stated otherwise.

## What changed and why
Stored features unchanged; the cloud view drops the 17 P-ANULAR columns (annulus pressure, measurement point undocumented). Edge view unchanged. Cloud = 4 channels x 17 = 68 features.

## Shapes
- X_edge [25488, 34], X_cloud [25488, 68]; edge columns lead cloud columns.
- Grouping: group_id as stored (episode). The by-well analysis runs this same directory with `--group-col well` (results under <variant>__by_well).


## Counts (POST-PLAN variant; windows and grouping identical to the parent)
- windows 25488, positives 9228, prevalence 0.362
- grouping `group_id`: 94 groups; groups with negatives 75, with positives 66; K = min(5, pos, neg) = 5
- grouping `well`: 13 groups; groups with negatives 13, with positives 12; K = min(5, pos, neg) = 5
