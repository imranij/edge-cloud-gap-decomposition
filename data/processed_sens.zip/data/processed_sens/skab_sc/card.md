# skab_sc (post-plan sensitivity variant; not confirmatory)

Shortcut-augmented views: the time-in-file variable t_start_s (the strongest SKAB shortcut, BA 0.961 alone) is added to the edge view and therefore to the cloud view. The information step then measures what the loop channels add beyond the drive channels AND the window's position in its recording.
Built by src/sens/designs/build_round3_variants.py.
