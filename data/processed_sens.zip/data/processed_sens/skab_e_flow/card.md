# skab_e_flow (post-plan sensitivity variant; not confirmatory)

Cloud view = the five drive channels plus Volume Flow RateRMS only (edge unchanged).
Built by src/sens/designs/build_round3_variants.py.
