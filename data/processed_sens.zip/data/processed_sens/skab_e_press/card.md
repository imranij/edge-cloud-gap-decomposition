# skab_e_press (post-plan sensitivity variant; not confirmatory)

Cloud view = the five drive channels plus Pressure only (edge unchanged).
Built by src/sens/designs/build_round3_variants.py.
