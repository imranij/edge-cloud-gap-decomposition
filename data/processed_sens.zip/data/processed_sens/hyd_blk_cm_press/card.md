# hyd_blk_cm_press (post-plan sensitivity variant; not confirmatory)

Copy of hyd_blocks (blocked-in-time grouping, 20 contiguous blocks; features, labels and edge view unchanged). Cloud view = EPS1, VS1, FS1, FS2, TS1, TS2, TS3, TS4 (136 features). Built by src/sens/designs/build_hyd_ablation.py.
