# Dataset variant `skab_edgeP` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/skab` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Columns only: the alternative admissible edge named in the parent card: edge = the five drive channels plus Pressure (pump discharge), 6 channels, 102 features; cloud = all eight channels with the six edge channels first (136 features, same values as the parent, reordered).

## Why
alternative edge definition. The parent card states that Pressure is measured at the pump discharge and a 6-channel edge is admissible but was not chosen as primary.

## How it was built
Column selection from the parent X_cloud by channel name; edge = ['Accelerometer1RMS', 'Accelerometer2RMS', 'Current', 'Temperature', 'Voltage', 'Pressure']; cloud = ['Accelerometer1RMS', 'Accelerometer2RMS', 'Current', 'Temperature', 'Voltage', 'Pressure', 'Thermocouple', 'Volume Flow RateRMS'] (edge first). Feature values unchanged. bytes.json recomputed for the new channel counts (17 features x 4 bytes per channel; 60 float32 samples per channel).

## Counts
- Windows: 4533; positives: 1371; prevalence: 0.3024.
- Groups: 42; groups containing positives: 34; groups containing negatives: 42; groups mixing both labels: 34.
- Resulting outer K = min(5, 34, 42) = 5; repeats for J = 20: 4.
- Group sizes (windows): min 68, median 110, max 129; positives per positive group: min 17, median 43, max 62.

Edge features: 102; cloud features: 136; edge = first 102 cloud columns (checked). No NaN or inf.
