# POST-PLAN sensitivity variant `threew_inorm` (parent: data/processed/threew)

Built by src/sens/threewseu/build.py (secondary sensitivity analysis). Not confirmatory: it cannot change any pre-specified verdict. Windows, labels, meta (all columns, row order, window_id) and channels are copied unchanged from the parent; raw_*.npy are not included (pairs A and B do not use them). Features are recomputed with escalation.features.window_features from the parent's stored raw windows (one call per view, channels in the stored order, edge channels first) unless stated otherwise.

## What changed and why
Per-instance robust normalisation: for each instance (meta.instance, 445) and channel, the median and the IQR (floor 1e-6) are computed over all samples of that instance's kept windows, and every sample is mapped to (x - median) / IQR before all 17 features are computed. This is NON-CAUSAL: the statistics use samples later in the same instance, which a deployed node would not have. Instances whose channel is median-imputed or frozen become all-zero for that channel (IQR 0 -> floor; x - median = 0).

## Shapes
- X_edge [25488, 34], X_cloud [25488, 85]; edge columns lead cloud columns.
- Grouping: group_id as stored (episode). The by-well analysis runs this same directory with `--group-col well` (results under <variant>__by_well).


## Counts (POST-PLAN variant; windows and grouping identical to the parent)
- windows 25488, positives 9228, prevalence 0.362
- grouping `group_id`: 94 groups; groups with negatives 75, with positives 66; K = min(5, pos, neg) = 5
- grouping `well`: 13 groups; groups with negatives 13, with positives 12; K = min(5, pos, neg) = 5
