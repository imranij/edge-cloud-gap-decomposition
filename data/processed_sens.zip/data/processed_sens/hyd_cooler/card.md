# Dataset variant `hyd_cooler` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/hydraulic` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Grouping only: group_id = cooler level (3 groups: 3, 20, 100), a hold-out-nuisance-condition design: each outer fold tests on one level never seen in training. order is kept from the main run (position within the original group; groups are not contiguous in time here).

## Why
hold-out-nuisance-condition splits. With one group per level every repeat is the same partition, so only the first repeat (--splits 0:3) is run and reported per fold, without NB intervals (SENS_BRIEF).

## How it was built
group_id from meta.cooler; features unchanged.

## Counts
- Windows: 2205; positives: 984; prevalence: 0.4463.
- Groups: 3; groups containing positives: 3; groups containing negatives: 3; groups mixing both labels: 3.
- Resulting outer K = min(5, 3, 3) = 3; repeats for J = 20: 7.
- Group sizes (windows): min 732, median 732, max 741; positives per positive group: min 328, median 328, max 328.

| group_id | windows | positives |
|---|---:|---:|
| cooler100 | 741 | 328 |
| cooler20 | 732 | 328 |
| cooler3 | 732 | 328 |

Edge features: 34; cloud features: 238; edge = first 34 cloud columns (checked). No NaN or inf.
