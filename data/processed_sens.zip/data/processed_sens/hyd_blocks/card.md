# Dataset variant `hyd_blocks` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/hydraulic` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Grouping only: group_id = 'b%02d' % (cycle // 111), i.e. 20 contiguous blocks of 111 load cycles (the last block has 96). Features, labels and windows are unchanged. order = cycle position within the block (used only by router R9); the main-run group_id and order are kept as group_id_orig and order_orig. Blocks may contain both labels (allowed by the grouped stratified splitter).

## Why
Pre-declared deconfounded variant (plan/postplan/DECONF_DECLARATION.md). The parent card documents that adjacent groups share pump condition and thermal history, so a grouped split that puts neighbouring groups in train and test leaks; blocked-in-time grouping keeps 111-cycle stretches together.

## How it was built
meta.cycle // 111; copied X_edge/X_cloud unchanged.

## Counts
- Windows: 2205; positives: 984; prevalence: 0.4463.
- Groups: 20; groups containing positives: 16; groups containing negatives: 20; groups mixing both labels: 16.
- Resulting outer K = min(5, 16, 20) = 5; repeats for J = 20: 4.
- Group sizes (windows): min 96, median 111, max 111; positives per positive group: min 12, median 60, max 82.

| group_id | windows | positives |
|---|---:|---:|
| b00 | 111 | 0 |
| b01 | 111 | 12 |
| b02 | 111 | 70 |
| b03 | 111 | 82 |
| b04 | 111 | 79 |
| b05 | 111 | 60 |
| b06 | 111 | 25 |
| b07 | 111 | 0 |
| b08 | 111 | 57 |
| b09 | 111 | 60 |
| b10 | 111 | 60 |
| b11 | 111 | 69 |
| b12 | 111 | 82 |
| b13 | 111 | 0 |
| b14 | 111 | 0 |
| b15 | 111 | 82 |
| b16 | 111 | 80 |
| b17 | 111 | 60 |
| b18 | 111 | 60 |
| b19 | 96 | 46 |

Edge features: 34; cloud features: 238; edge = first 34 cloud columns (checked). No NaN or inf.
