# Dataset variant `skab_base` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/skab` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Feature values only: from every feature, subtract the mean of that feature over the recording's first five windows (t_start_s in {0, 10, 20, 30, 40}, i.e. the first 100 s of the recording). 'Recording' = source file (meta.file, 35 files); the eight anomaly-free chunks share one recording and therefore one baseline (the first 100 s of anomaly-free.csv, which lie in free_0). Verified: every recording has exactly 5 such windows and all 175 are normal (label 0 and label_frac 0, i.e. no anomalous second). Normalised once on the cloud matrix; edge = first 85 columns.

Causality: the baseline uses only the first 100 s of each recording, so it is causal for every window starting at or after 40 s; the five baseline windows themselves use up to 60 s of data after their own end. No scaling, only an offset.

## Why
a deployable alternative to within-file normalisation that removes per-recording offsets without using future or anomalous data.

## How it was built
per file: x - mean(x over windows with t_start_s <= 40), float64, cast to float32.

## Counts
- Windows: 4533; positives: 1371; prevalence: 0.3024.
- Groups: 42; groups containing positives: 34; groups containing negatives: 42; groups mixing both labels: 34.
- Resulting outer K = min(5, 34, 42) = 5; repeats for J = 20: 4.
- Group sizes (windows): min 68, median 110, max 129; positives per positive group: min 17, median 43, max 62.

Edge features: 85; cloud features: 136; edge = first 85 cloud columns (checked). No NaN or inf.
