# POST-PLAN sensitivity variant `threew_zn` (parent: data/processed/threew)

Built by src/sens/threewseu/build.py (secondary sensitivity analysis). Not confirmatory: it cannot change any pre-specified verdict. Windows, labels, meta (all columns, row order, window_id) and channels are copied unchanged from the parent; raw_*.npy are not included (pairs A and B do not use them). Features are recomputed with escalation.features.window_features from the parent's stored raw windows (one call per view, channels in the stored order, edge channels first) unless stated otherwise.

## What changed and why
Every window is z-normalised per channel ((x - mean) / max(sd, 1e-6), float64) before the features, then only the scale-free features are kept: skew, kurt, crest, shape, impulse, zcr, spec_centroid, spec_spread, spec_entropy, band_lo, band_mid, band_hi (12 per channel). mean, std, rms, p2p and mad are dropped. Neither absolute level nor absolute scale is visible to the models.

## Shapes
- X_edge [25488, 24], X_cloud [25488, 60]; edge columns lead cloud columns.
- Grouping: group_id as stored (episode). The by-well analysis runs this same directory with `--group-col well` (results under <variant>__by_well).


## Counts (POST-PLAN variant; windows and grouping identical to the parent)
- windows 25488, positives 9228, prevalence 0.362
- grouping `group_id`: 94 groups; groups with negatives 75, with positives 66; K = min(5, pos, neg) = 5
- grouping `well`: 13 groups; groups with negatives 13, with positives 12; K = min(5, pos, neg) = 5
