# hyd_blocks_sc2 (post-plan sensitivity variant; not confirmatory)

hyd_blocks with the cycle index AND the component-setting codes (cooler, valve, accumulator) added to the edge view and therefore to the cloud view. The information step then measures what the cloud-only sensors add beyond the drive sensors, the time position and the operating settings.
