# skab_e_thermo (post-plan sensitivity variant; not confirmatory)

Cloud view = the five drive channels plus Thermocouple only (edge unchanged).
Built by src/sens/designs/build_round3_variants.py.
