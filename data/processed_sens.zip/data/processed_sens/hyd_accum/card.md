# Dataset variant `hyd_accum` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/hydraulic` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Grouping only: group_id = accumulator level (4 groups: 90, 100, 115, 130), a hold-out-nuisance-condition design: each outer fold tests on one level never seen in training. order is kept from the main run (position within the original group; groups are not contiguous in time here).

## Why
hold-out-nuisance-condition splits. With one group per level every repeat is the same partition, so only the first repeat (--splits 0:4) is run and reported per fold, without NB intervals (SENS_BRIEF).

## How it was built
group_id from meta.accumulator; features unchanged.

## Counts
- Windows: 2205; positives: 984; prevalence: 0.4463.
- Groups: 4; groups containing positives: 4; groups containing negatives: 4; groups mixing both labels: 4.
- Resulting outer K = min(5, 4, 4) = 4; repeats for J = 20: 5.
- Group sizes (windows): min 399, median 499, max 808; positives per positive group: min 246, median 246, max 246.

| group_id | windows | positives |
|---|---:|---:|
| accumulator100 | 399 | 246 |
| accumulator115 | 399 | 246 |
| accumulator130 | 599 | 246 |
| accumulator90 | 808 | 246 |

Edge features: 34; cloud features: 238; edge = first 34 cloud columns (checked). No NaN or inf.
