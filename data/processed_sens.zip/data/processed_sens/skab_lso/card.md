# Dataset variant `skab_lso` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/skab` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Grouping only: group_id = session (recording date: 2020-02-08 = anomaly-free + other/5-14; 2020-03-01 = other/1-4; 2020-03-09 = valve1 + valve2). Each session contains both classes, so K = 3 and each outer fold tests on one whole session (leave-session-out). order kept (time order within the file). Features unchanged.

## Why
leave-session-out. With one group per session every repeat is the same partition, so only --splits 0:3 is run and reported per fold, without NB intervals.

## How it was built
group_id from meta.session.

## Counts
- Windows: 4533; positives: 1371; prevalence: 0.3024.
- Groups: 3; groups containing positives: 3; groups containing negatives: 3; groups mixing both labels: 3.
- Resulting outer K = min(5, 3, 3) = 3; repeats for J = 20: 7.
- Group sizes (windows): min 364, median 2021, max 2148; positives per positive group: min 136, median 412, max 823.

| group_id | windows | positives |
|---|---:|---:|
| 2020-02-08 | 2021 | 412 |
| 2020-03-01 | 364 | 136 |
| 2020-03-09 | 2148 | 823 |

Edge features: 85; cloud features: 136; edge = first 85 cloud columns (checked). No NaN or inf.
