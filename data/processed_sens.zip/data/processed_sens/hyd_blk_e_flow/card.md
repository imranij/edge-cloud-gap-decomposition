# hyd_blk_e_flow (post-plan sensitivity variant; not confirmatory)

Copy of hyd_blocks (blocked-in-time grouping, 20 contiguous blocks; features, labels and edge view unchanged). Cloud view = EPS1, VS1, FS1, FS2 (68 features). Built by src/sens/designs/build_hyd_ablation.py.
