# POST-PLAN sensitivity variant `seu_dm` (parent: data/processed/seu)

Built by src/sens/threewseu/build.py (DECLARED deconfounded variant, plan/postplan/DECONF_DECLARATION.md). Not confirmatory: it cannot change any pre-specified verdict. Windows, labels, meta (all columns, row order, window_id) and channels are copied unchanged from the parent; raw_*.npy are not included (pairs A and B do not use them). Features are recomputed with escalation.features.window_features from the parent's stored raw windows (one call per view, channels in the stored order, edge channels first) unless stated otherwise.

## What changed and why
Every window is de-meaned per channel (x - mean over the window's samples, float64) before the features, so no feature can carry the absolute level of a channel. The `mean` feature is then identically zero and its column is dropped: 16 features per channel. Note that after de-meaning `rms` equals `std`; both columns are kept because the declaration specify only the mean drop. Scale (std, p2p, mad) is still present.

## Shapes
- X_edge [8000, 32], X_cloud [8000, 128]; edge columns lead cloud columns.


## Counts (POST-PLAN variant; windows and grouping identical to the parent)
- windows 8000, positives 6400, prevalence 0.800
- grouping `group_id`: 20 groups; groups with negatives 4, with positives 16; K = min(5, pos, neg) = 4
