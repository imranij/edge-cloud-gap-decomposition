# Dataset variant `skab_filez` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/skab` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Feature values only: every one of the 136 cloud feature columns is z-scored within its group_id (one experiment file, or one 1245-s chunk of the anomaly-free recording), using that group's mean and population sd over all its windows (sd floor 1e-6). The cloud matrix is normalised once and the edge matrix is its first 85 columns, so the nested-view property holds exactly. 49 (group, column) pairs hit the sd floor (constant columns become 0). Rows, labels, grouping unchanged.

**This normalisation is NON-CAUSAL**: each window is normalised with statistics of its whole recording, including later windows and the anomalous segment itself. It removes recording-level (and therefore session-level) offsets and scales, but it also uses information a deployed edge node would not have.

## Why
Pre-declared deconfounded variant (DECONF_DECLARATION.md) ('features normalised within each file'). The parent card documents that normal windows come from other sessions than the anomaly-free chunks, so absolute levels can identify the session/recording rather than the fault.

## How it was built
per group: (x - mean_g) / max(sd_g, 1e-6) on float64, cast to float32.

## Counts
- Windows: 4533; positives: 1371; prevalence: 0.3024.
- Groups: 42; groups containing positives: 34; groups containing negatives: 42; groups mixing both labels: 34.
- Resulting outer K = min(5, 34, 42) = 5; repeats for J = 20: 4.
- Group sizes (windows): min 68, median 110, max 129; positives per positive group: min 17, median 43, max 62.

Edge features: 85; cloud features: 136; edge = first 85 cloud columns (checked). No NaN or inf.
