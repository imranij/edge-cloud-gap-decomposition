# Dataset variant `hyd_weak` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/hydraulic` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Rows only: the 492 windows with fault_type = pump_leak_severe are removed, so the positive class is weak leakage only. Main grouping (group_id unchanged), features unchanged.

## Why
report weak and severe leakage separately.

## How it was built
meta.fault_type != 'pump_leak_severe'.

## Counts
- Windows: 1713; positives: 492; prevalence: 0.2872.
- Groups: 143; groups containing positives: 60; groups containing negatives: 83; groups mixing both labels: 0.
- Resulting outer K = min(5, 60, 83) = 5; repeats for J = 20: 4.
- Group sizes (windows): min 1, median 10, max 53; positives per positive group: min 1, median 10, max 10.

Edge features: 34; cloud features: 238; edge = first 34 cloud columns (checked). No NaN or inf.
