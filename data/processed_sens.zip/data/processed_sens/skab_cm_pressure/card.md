# Dataset variant `skab_cm_pressure` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/skab` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Columns only: cloud = all eight channels minus the loop channel Pressure (7 channels, 119 features); edge unchanged (5 drive channels, 85 features).

## Why
which loop channel carries the SKAB pair A model x information interaction of about 0.12.

## How it was built
Column selection from the parent X_cloud by channel name; edge = ['Accelerometer1RMS', 'Accelerometer2RMS', 'Current', 'Temperature', 'Voltage']; cloud = ['Accelerometer1RMS', 'Accelerometer2RMS', 'Current', 'Temperature', 'Voltage', 'Thermocouple', 'Volume Flow RateRMS'] (edge first). Feature values unchanged. bytes.json recomputed for the new channel counts (17 features x 4 bytes per channel; 60 float32 samples per channel).

## Counts
- Windows: 4533; positives: 1371; prevalence: 0.3024.
- Groups: 42; groups containing positives: 34; groups containing negatives: 42; groups mixing both labels: 34.
- Resulting outer K = min(5, 34, 42) = 5; repeats for J = 20: 4.
- Group sizes (windows): min 68, median 110, max 129; positives per positive group: min 17, median 43, max 62.

Edge features: 85; cloud features: 119; edge = first 85 cloud columns (checked). No NaN or inf.
