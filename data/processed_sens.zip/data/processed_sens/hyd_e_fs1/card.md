# hyd_e_fs1 (post-plan sensitivity variant; not confirmatory)

Hydraulic data with the original grouping; cloud view = EPS1, VS1 and FS1 only (51 features). Used only by the redesigned cooler hold-out design hyd_cooler2_fs1.
