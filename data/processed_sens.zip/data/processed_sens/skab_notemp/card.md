# Dataset variant `skab_notemp` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/skab` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Columns only: the motor-body Temperature channel is removed from edge and cloud, and the fluid Thermocouple channel is removed from cloud (edge = 4 channels, 68 features; cloud = 6 channels, 102 features). Rows, labels and grouping unchanged.

## Why
Hypothesis tested: temperature warm-up drifts with run time and the label follows a fixed script inside each file (parent card caveat 1), so temperature may act as a clock.

## How it was built
Column selection from the parent X_cloud by channel name; edge = ['Accelerometer1RMS', 'Accelerometer2RMS', 'Current', 'Voltage']; cloud = ['Accelerometer1RMS', 'Accelerometer2RMS', 'Current', 'Voltage', 'Pressure', 'Volume Flow RateRMS'] (edge first). Feature values unchanged. bytes.json recomputed for the new channel counts (17 features x 4 bytes per channel; 60 float32 samples per channel).

## Counts
- Windows: 4533; positives: 1371; prevalence: 0.3024.
- Groups: 42; groups containing positives: 34; groups containing negatives: 42; groups mixing both labels: 34.
- Resulting outer K = min(5, 34, 42) = 5; repeats for J = 20: 4.
- Group sizes (windows): min 68, median 110, max 129; positives per positive group: min 17, median 43, max 62.

Edge features: 68; cloud features: 102; edge = first 68 cloud columns (checked). No NaN or inf.
