# hyd_blocks_sc (post-plan sensitivity variant; not confirmatory)

hyd_blocks (20 contiguous blocks) with the global cycle index (the hydraulic shortcut variable) added to the edge view and therefore to the cloud view.
Built by src/sens/designs/build_round3_variants.py.
