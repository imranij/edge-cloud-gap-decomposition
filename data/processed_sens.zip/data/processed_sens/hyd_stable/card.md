# Dataset variant `hyd_stable` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/hydraulic` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Rows only: the 756 transitional cycles (meta.stable == 1, i.e. static conditions possibly not yet reached; includes the 36 singleton transition groups) are removed. Main grouping, features unchanged. Removed rows: 732 normal, 12 weak, 12 severe.

## Why
'the result with transitional cycles excluded'.

## How it was built
meta.stable == 0.

## Counts
- Windows: 1449; positives: 960; prevalence: 0.6625.
- Groups: 144; groups containing positives: 96; groups containing negatives: 48; groups mixing both labels: 0.
- Resulting outer K = min(5, 96, 48) = 5; repeats for J = 20: 4.
- Group sizes (windows): min 10, median 10, max 19; positives per positive group: min 10, median 10, max 10.

Edge features: 34; cloud features: 238; edge = first 34 cloud columns (checked). No NaN or inf.
