# hyd_blk_e_press (post-plan sensitivity variant; not confirmatory)

Copy of hyd_blocks (blocked-in-time grouping, 20 contiguous blocks; features, labels and edge view unchanged). Cloud view = EPS1, VS1, PS1, PS2, PS3, PS4, PS5, PS6 (136 features). Built by src/sens/designs/build_hyd_ablation.py.
