# Dataset variant `hyd_runs` (POST-PLAN sensitivity analysis; not confirmatory)

Parent: `data/processed/hydraulic` (see its card.md for source, licence, channels, labels and windowing). Built by `src/sens/hydskab/build.py`. Pairs A and B only; raw_*.npy are not provided.

## What changed
Grouping only: group_id = 'run%03d' % run_id, the 194 maximal runs of constant (cooler, valve, pump, accumulator) setting WITHOUT the main-run chunking of runs longer than 60 cycles (the 200-, 200- and 210-cycle runs stay whole). order = position within the run.

## Why
'without chunking constant-setting runs'. The main grouping split three long runs into 4 chunks each, so chunks of one run could fall in train and test.

## How it was built
group_id from meta.run_id; features unchanged.

## Counts
- Windows: 2205; positives: 984; prevalence: 0.4463.
- Groups: 194; groups containing positives: 120; groups containing negatives: 74; groups mixing both labels: 0.
- Resulting outer K = min(5, 120, 74) = 5; repeats for J = 20: 4.
- Group sizes (windows): min 1, median 10, max 210; positives per positive group: min 1, median 10, max 10.

Edge features: 34; cloud features: 238; edge = first 34 cloud columns (checked). No NaN or inf.
